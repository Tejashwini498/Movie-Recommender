#!/usr/bin/env python3
"""
CineMatch - Quick Start
Trains the model and launches the API server.
"""
import subprocess
import sys
import os

print("=" * 50)
print("  CineMatch — Movie Recommendation System")
print("=" * 50)

# Step 1: Generate data
print("\n[1/3] Generating dataset...")
subprocess.run([sys.executable, "data/generate_dataset.py"], check=True)

# Step 2: Train model
print("\n[2/3] Training recommendation models...")
subprocess.run([sys.executable, "backend/recommender.py"], check=True)

# Step 3: Start server
print("\n[3/3] Starting Flask API server...")
print("\n✓ Open frontend/index.html in your browser")
print("✓ API running at http://localhost:5000\n")
os.chdir(os.path.dirname(os.path.abspath(__file__)))
subprocess.run([sys.executable, "backend/app.py"])
