"""
Generate a rich movie dataset for the recommendation system.
In production, replace with TMDb API or MovieLens dataset.
"""
import pandas as pd
import numpy as np
import json
import random

random.seed(42)
np.random.seed(42)

MOVIES = [
    # Action
    ("The Dark Knight", 2008, ["Action","Crime","Drama"], "Christopher Nolan", ["Christian Bale","Heath Ledger","Aaron Eckhart"], 9.0, "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests."),
    ("Mad Max: Fury Road", 2015, ["Action","Adventure","Sci-Fi"], "George Miller", ["Tom Hardy","Charlize Theron"], 8.1, "In a post-apocalyptic wasteland, a woman rebels against a tyrannical ruler in search of her homeland."),
    ("John Wick", 2014, ["Action","Crime","Thriller"], "Chad Stahelski", ["Keanu Reeves","Michael Nyqvist"], 7.4, "An ex-hit-man comes out of retirement to track down the gangsters that killed his dog."),
    ("Die Hard", 1988, ["Action","Thriller"], "John McTiernan", ["Bruce Willis","Alan Rickman"], 8.2, "An NYPD officer tries to save his wife and several others taken hostage by German terrorists."),
    ("The Matrix", 1999, ["Action","Sci-Fi"], "Wachowski Sisters", ["Keanu Reeves","Laurence Fishburne","Carrie-Anne Moss"], 8.7, "A computer hacker learns about the true nature of reality and his role in the war against its controllers."),
    ("Gladiator", 2000, ["Action","Adventure","Drama"], "Ridley Scott", ["Russell Crowe","Joaquin Phoenix"], 8.5, "A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family."),
    ("Top Gun: Maverick", 2022, ["Action","Drama"], "Joseph Kosinski", ["Tom Cruise","Miles Teller"], 8.3, "After thirty years, Maverick is still pushing the envelope as a top naval aviator."),
    ("Mission: Impossible – Fallout", 2018, ["Action","Adventure","Thriller"], "Christopher McQuarrie", ["Tom Cruise","Henry Cavill"], 7.7, "Ethan Hunt and his IMF team race against time after a mission gone wrong."),

    # Drama
    ("The Shawshank Redemption", 1994, ["Drama"], "Frank Darabont", ["Tim Robbins","Morgan Freeman"], 9.3, "Two imprisoned men bond over years, finding solace and redemption through acts of decency."),
    ("Forrest Gump", 1994, ["Drama","Romance"], "Robert Zemeckis", ["Tom Hanks","Robin Wright"], 8.8, "The presidencies of Kennedy and Johnson, Vietnam, Watergate through the eyes of an Alabama man."),
    ("Schindler's List", 1993, ["Biography","Drama","History"], "Steven Spielberg", ["Liam Neeson","Ben Kingsley"], 9.0, "In German-occupied Poland during WWII, Oskar Schindler saves his Jewish employees from the Holocaust."),
    ("The Godfather", 1972, ["Crime","Drama"], "Francis Ford Coppola", ["Marlon Brando","Al Pacino"], 9.2, "The aging patriarch of an organized crime dynasty transfers control to his reluctant son."),
    ("Good Will Hunting", 1997, ["Drama","Romance"], "Gus Van Sant", ["Matt Damon","Robin Williams"], 8.3, "A janitor at MIT has a gift for mathematics and a psychologist helps him with the rest."),
    ("A Beautiful Mind", 2001, ["Biography","Drama"], "Ron Howard", ["Russell Crowe","Ed Harris"], 8.2, "A brilliant but asocial mathematician accepts secret work in cryptography, which leads to his downfall."),
    ("The Pursuit of Happyness", 2006, ["Biography","Drama"], "Gabriele Muccino", ["Will Smith","Jaden Smith"], 8.0, "A struggling salesman takes custody of his son as he embarks on the quest to become a stockbroker."),
    ("Parasite", 2019, ["Comedy","Drama","Thriller"], "Bong Joon Ho", ["Song Kang-ho","Lee Sun-kyun"], 8.5, "Greed and class discrimination threaten a symbiotic relationship between two families."),

    # Sci-Fi
    ("Interstellar", 2014, ["Adventure","Drama","Sci-Fi"], "Christopher Nolan", ["Matthew McConaughey","Anne Hathaway"], 8.7, "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival."),
    ("Inception", 2010, ["Action","Adventure","Sci-Fi"], "Christopher Nolan", ["Leonardo DiCaprio","Joseph Gordon-Levitt"], 8.8, "A thief who steals corporate secrets through dream-sharing technology is given the inverse task."),
    ("Arrival", 2016, ["Drama","Mystery","Sci-Fi"], "Denis Villeneuve", ["Amy Adams","Jeremy Renner"], 7.9, "A linguist works with the military to communicate with alien lifeforms after twelve mysterious spacecraft appear."),
    ("Blade Runner 2049", 2017, ["Action","Drama","Mystery"], "Denis Villeneuve", ["Ryan Gosling","Harrison Ford"], 8.0, "A young blade runner unearths a long-buried secret that has the potential to plunge society into chaos."),
    ("Ex Machina", 2014, ["Drama","Sci-Fi","Thriller"], "Alex Garland", ["Domhnall Gleeson","Alicia Vikander"], 7.7, "A programmer is selected to participate in a ground-breaking experiment in synthetic intelligence."),
    ("2001: A Space Odyssey", 1968, ["Adventure","Sci-Fi"], "Stanley Kubrick", ["Keir Dullea","Gary Lockwood"], 8.3, "After discovering a mysterious artifact buried beneath the lunar surface, a space odyssey begins."),
    ("WALL-E", 2008, ["Animation","Adventure","Family"], "Andrew Stanton", ["Ben Burtt","Elissa Knight"], 8.4, "In the distant future, a small waste-collecting robot inadvertently embarks on a space journey."),
    ("Dune", 2021, ["Action","Adventure","Drama"], "Denis Villeneuve", ["Timothée Chalamet","Rebecca Ferguson"], 8.0, "A noble family becomes embroiled in a war for control over a desert planet and its spice."),

    # Horror/Thriller
    ("Get Out", 2017, ["Horror","Mystery","Thriller"], "Jordan Peele", ["Daniel Kaluuya","Allison Williams"], 7.7, "A young African-American visits his white girlfriend's parents for the weekend."),
    ("Hereditary", 2018, ["Drama","Horror","Mystery"], "Ari Aster", ["Toni Collette","Alex Wolff"], 7.3, "A grieving family is haunted by tragic and disturbing occurrences."),
    ("The Silence of the Lambs", 1991, ["Crime","Drama","Thriller"], "Jonathan Demme", ["Jodie Foster","Anthony Hopkins"], 8.6, "A young FBI cadet must receive the help of an incarcerated cannibal killer to help catch another serial killer."),
    ("Se7en", 1995, ["Crime","Drama","Mystery"], "David Fincher", ["Morgan Freeman","Brad Pitt"], 8.6, "Two detectives hunt a serial killer who uses the seven deadly sins as motives."),
    ("A Quiet Place", 2018, ["Drama","Horror","Sci-Fi"], "John Krasinski", ["Emily Blunt","John Krasinski"], 7.5, "A family struggles to survive in a post-apocalyptic world inhabited by blind monsters."),
    ("Midsommar", 2019, ["Drama","Horror","Mystery"], "Ari Aster", ["Florence Pugh","Jack Reynor"], 7.1, "A couple travels to Sweden to visit a rural hometown's midsummer festival."),

    # Romance/Comedy
    ("La La Land", 2016, ["Comedy","Drama","Music"], "Damien Chazelle", ["Ryan Gosling","Emma Stone"], 8.0, "While navigating their careers in Los Angeles, a pianist and an actress fall in love."),
    ("Crazy, Stupid, Love", 2011, ["Comedy","Drama","Romance"], "Glenn Ficarra", ["Steve Carell","Ryan Gosling"], 7.4, "A middle-aged husband's life changes when he meets a younger man who helps him rediscover his manhood."),
    ("When Harry Met Sally", 1989, ["Comedy","Drama","Romance"], "Rob Reiner", ["Billy Crystal","Meg Ryan"], 7.6, "Harry and Sally have known each other for years and are trying to determine if men and women can be friends."),
    ("The Grand Budapest Hotel", 2014, ["Adventure","Comedy","Crime"], "Wes Anderson", ["Ralph Fiennes","Tony Revolori"], 8.1, "The adventures of a legendary concierge and his trusted lobby boy."),
    ("Knives Out", 2019, ["Comedy","Crime","Drama"], "Rian Johnson", ["Daniel Craig","Chris Evans"], 7.9, "A detective investigates the death of a patriarch of an eccentric, combative family."),
    ("Everything Everywhere All at Once", 2022, ["Action","Adventure","Comedy"], "Daniels", ["Michelle Yeoh","Ke Huy Quan"], 7.8, "A middle-aged Chinese immigrant is swept up in an insane adventure where she can tap into the lives of parallel universes."),

    # Animation
    ("Spirited Away", 2001, ["Animation","Adventure","Family"], "Hayao Miyazaki", ["Daveigh Chase","Suzanne Pleshette"], 8.6, "During her family's move, a sullen girl wanders into a world ruled by gods, witches and monsters."),
    ("Spider-Man: Into the Spider-Verse", 2018, ["Animation","Action","Adventure"], "Bob Persichetti", ["Shameik Moore","Jake Johnson"], 8.4, "Teen Miles Morales becomes Spider-Man, joining alternate universe variants to stop a threat."),
    ("Toy Story", 1995, ["Animation","Adventure","Comedy"], "John Lasseter", ["Tom Hanks","Tim Allen"], 8.3, "A cowboy doll is profoundly threatened and jealous when a new spaceman figure becomes his owner's favorite."),
    ("The Lion King", 1994, ["Animation","Adventure","Drama"], "Roger Allers", ["Matthew Broderick","Jeremy Irons"], 8.5, "Lion prince Simba flees his kingdom only to learn the true meaning of responsibility and bravery."),

    # Thriller/Mystery
    ("Gone Girl", 2014, ["Drama","Mystery","Thriller"], "David Fincher", ["Ben Affleck","Rosamund Pike"], 8.1, "With his wife's disappearance having become the focus of a media frenzy, Nick Dunne becomes a suspect."),
    ("Shutter Island", 2010, ["Mystery","Thriller"], "Martin Scorsese", ["Leonardo DiCaprio","Emily Mortimer"], 8.1, "In 1954, two U.S. marshals are sent to a mental asylum on a remote island to investigate the disappearance of a patient."),
    ("Memento", 2000, ["Mystery","Thriller"], "Christopher Nolan", ["Guy Pearce","Carrie-Anne Moss"], 8.4, "A man with short-term memory loss attempts to track down his wife's murderer."),
    ("Prisoners", 2013, ["Crime","Drama","Mystery"], "Denis Villeneuve", ["Hugh Jackman","Jake Gyllenhaal"], 8.1, "When Keller Dover's daughter and her friend go missing, he takes matters into his own hands."),
    ("The Prestige", 2006, ["Drama","Mystery","Sci-Fi"], "Christopher Nolan", ["Christian Bale","Hugh Jackman"], 8.5, "Two stage magicians engage in competitive one-upmanship in an attempt to create the ultimate illusion."),

    # Adventure/Fantasy
    ("The Lord of the Rings: The Fellowship of the Ring", 2001, ["Adventure","Drama","Fantasy"], "Peter Jackson", ["Elijah Wood","Ian McKellen"], 8.8, "A meek hobbit and eight companions set out on a journey to destroy the powerful One Ring."),
    ("Harry Potter and the Sorcerer's Stone", 2001, ["Adventure","Family","Fantasy"], "Chris Columbus", ["Daniel Radcliffe","Rupert Grint"], 7.6, "Rescued from the outrageous neglect of his aunt and uncle, Harry Potter's life changes forever."),
    ("Avatar", 2009, ["Action","Adventure","Fantasy"], "James Cameron", ["Sam Worthington","Zoe Saldana"], 7.9, "A paraplegic Marine is dispatched to the moon Pandora on a unique mission, but becomes torn between duty and a new world."),
    ("The Revenant", 2015, ["Action","Adventure","Drama"], "Alejandro G. Iñárritu", ["Leonardo DiCaprio","Tom Hardy"], 8.0, "A frontiersman on a fur trading expedition fights for survival after being mauled by a bear."),
]

def generate_dataset():
    records = []
    for i, movie in enumerate(MOVIES):
        title, year, genres, director, cast, rating, overview = movie
        records.append({
            "movie_id": i + 1,
            "title": title,
            "year": year,
            "genres": "|".join(genres),
            "director": director,
            "cast": "|".join(cast),
            "rating": rating,
            "vote_count": random.randint(50000, 2500000),
            "overview": overview,
            "runtime": random.randint(88, 185),
            "language": "en",
            "popularity": round(random.uniform(20, 200), 2),
        })
    df = pd.DataFrame(records)
    df.to_csv("/home/claude/movie-recommender/data/movies.csv", index=False)
    print(f"Generated {len(df)} movies")

    # Generate user ratings for collaborative filtering
    user_ratings = []
    num_users = 200
    for user_id in range(1, num_users + 1):
        # Each user rates 8–25 random movies
        n_rated = random.randint(8, 25)
        rated_movies = random.sample(range(1, len(MOVIES)+1), n_rated)
        for movie_id in rated_movies:
            base_rating = MOVIES[movie_id-1][5]  # use IMDb rating as base
            noise = random.gauss(0, 0.8)
            user_rating = round(min(10, max(1, base_rating + noise)), 1)
            user_ratings.append({"user_id": user_id, "movie_id": movie_id, "rating": user_rating})

    ratings_df = pd.DataFrame(user_ratings)
    ratings_df.to_csv("/home/claude/movie-recommender/data/ratings.csv", index=False)
    print(f"Generated {len(ratings_df)} ratings from {num_users} users")
    return df, ratings_df

if __name__ == "__main__":
    generate_dataset()
