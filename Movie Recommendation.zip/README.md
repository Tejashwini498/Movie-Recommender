# 🎬 CineMatch — AI Movie Recommendation System

> Personalized movie recommendations powered by Content-Based Filtering, Collaborative Filtering, and a Hybrid ML approach.

![Python](https://img.shields.io/badge/Python-3.10+-blue?style=flat-square)
![Flask](https://img.shields.io/badge/Flask-3.0-green?style=flat-square)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.4-orange?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-purple?style=flat-square)

---

## 📌 Objective

Develop a Movie Recommendation System that uses machine learning techniques to recommend relevant movies based on similarity analysis. The system includes dataset preprocessing, search functionality, recommendation generation (content-based + collaborative filtering + hybrid), and a web-based UI.

---

## ✨ Features

- **Content-Based Filtering** — TF-IDF vectorization on genres, cast, director, and overview to find similar movies
- **Collaborative Filtering** — User-based CF using cosine similarity across a 200-user rating matrix
- **Hybrid Recommender** — Weighted combination of both approaches for improved personalization
- **Movie Search** — Semantic + title-match search across the catalog
- **User Rating System** — Submit ratings (1–10) that update your personalized recommendations in real time
- **Genre Filtering** — Browse movies by genre with sorting options
- **REST API** — 10 Flask endpoints for movies, search, recommendations, ratings, and stats
- **Cinematic UI** — Dark-mode frontend with animated poster art and smooth interactions

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| ML / Data | Python, scikit-learn (TF-IDF, cosine similarity), pandas, numpy |
| Backend | Flask, Flask-CORS |
| Frontend | Vanilla HTML/CSS/JS (no framework) |
| Data | Custom 49-movie dataset + 3,268 simulated user ratings |

---

## 🏗 Project Structure

```
movie-recommender/
├── backend/
│   ├── app.py            # Flask REST API (10 endpoints)
│   └── recommender.py    # ML engine: CB + CF + Hybrid
├── data/
│   ├── generate_dataset.py
│   ├── movies.csv        # 49 curated movies
│   └── ratings.csv       # 3,268 user ratings (200 users)
├── models/
│   └── recommender.pkl   # Trained model (generated on first run)
├── frontend/
│   └── index.html        # Full web app
├── requirements.txt
└── README.md
```

---

## ⚡ Setup & Run

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/movie-recommender.git
cd movie-recommender
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Generate data & train the model
```bash
python data/generate_dataset.py
python backend/recommender.py
```

### 4. Start the Flask API
```bash
python backend/app.py
# → Running on http://127.0.0.1:5000
```

### 5. Open the frontend
Open `frontend/index.html` in your browser, or serve it:
```bash
cd frontend && python -m http.server 8080
# → http://localhost:8080
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/movies` | All movies (paginated, sortable) |
| GET | `/api/movies/popular` | Most popular movies |
| GET | `/api/movies/toprated` | Highest rated movies |
| GET | `/api/movies/<id>` | Single movie detail |
| GET | `/api/search?q=<query>` | Search movies |
| GET | `/api/recommend/<id>` | Content-based recommendations |
| GET | `/api/recommend/user/<uid>` | Collaborative filtering picks |
| POST | `/api/rate` | Submit a user rating |
| GET | `/api/genres` | List all genres |
| GET | `/api/stats` | Dataset statistics |

---

## 🤖 ML Architecture

### Content-Based Filtering
- Builds a "soup" string from each movie: `genres × 2 + director × 2 + cast + overview`
- TF-IDF with bigrams (`ngram_range=(1,2)`) → sparse feature matrix
- Cosine similarity matrix for all movie pairs
- Query time: O(1) lookup in similarity matrix

### Collaborative Filtering
- User-movie rating matrix (200 users × 49 movies)
- Mean-centered normalization per user
- User-user cosine similarity
- Weighted prediction of unrated movies using top-20 similar users

### Hybrid
- Normalizes CB and CF scores to [0,1] with MinMaxScaler
- Weighted blend: `score = 0.6 × cb_score + 0.4 × cf_score`
- Falls back to content-based if user has no history

---

## 📊 Dataset

- **49 curated movies** across 16 genres (Action, Drama, Sci-Fi, Horror, Animation, etc.)
- **3,268 simulated ratings** from 200 synthetic users
- Ratings generated using Gaussian noise (σ=0.8) around each film's base IMDb-style score
- In production: replace with [MovieLens](https://grouplens.org/datasets/movielens/) or [TMDb API](https://www.themoviedb.org/documentation/api)

---

## 🚀 Future Enhancements

- [ ] TMDb API integration for real posters and metadata
- [ ] Matrix Factorization (SVD) for better CF
- [ ] User authentication and persistent rating history
- [ ] Docker deployment
- [ ] A/B testing framework for recommendation strategies

---

## 📄 License

MIT License © 2026
