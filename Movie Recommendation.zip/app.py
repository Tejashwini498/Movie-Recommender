"""
Flask REST API for Movie Recommendation System
Endpoints:
  GET  /api/movies          - all movies (paginated)
  GET  /api/movies/popular  - popular movies
  GET  /api/movies/toprated - top rated movies
  GET  /api/movies/<id>     - movie detail
  GET  /api/search?q=       - search movies
  GET  /api/recommend/<id>  - content-based recs
  GET  /api/recommend/user/<uid> - user-based CF recs
  POST /api/rate            - submit a rating
  GET  /api/genres          - list all genres
  GET  /api/movies/genre/<genre> - movies by genre
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
from recommender import load_model
import pandas as pd

app = Flask(__name__)
CORS(app)

# Load model at startup
print("Loading recommendation model...")
rec = load_model()
print("Model ready!")


def movie_to_dict(row):
    return {
        "id": int(row["movie_id"]),
        "title": row["title"],
        "year": int(row["year"]),
        "genres": row["genres"].split("|"),
        "director": row["director"],
        "cast": row["cast"].split("|"),
        "rating": float(row["rating"]),
        "vote_count": int(row["vote_count"]),
        "overview": row["overview"],
        "runtime": int(row["runtime"]),
        "popularity": float(row["popularity"]),
        "poster_color": genre_to_color(row["genres"].split("|")[0]),
    }


def genre_to_color(genre):
    colors = {
        "Action": "#e74c3c", "Drama": "#3498db", "Sci-Fi": "#9b59b6",
        "Comedy": "#f39c12", "Horror": "#2c3e50", "Romance": "#e91e63",
        "Thriller": "#1abc9c", "Animation": "#2ecc71", "Adventure": "#e67e22",
        "Crime": "#c0392b", "Biography": "#16a085", "Fantasy": "#8e44ad",
        "Mystery": "#2980b9", "Music": "#d35400", "History": "#7f8c8d",
        "Family": "#27ae60",
    }
    return colors.get(genre, "#607d8b")


def df_to_list(df):
    return [movie_to_dict(row) for _, row in df.iterrows()]


@app.route("/api/movies", methods=["GET"])
def get_movies():
    page = int(request.args.get("page", 1))
    per_page = int(request.args.get("per_page", 12))
    sort_by = request.args.get("sort", "popularity")
    df = rec.get_all_movies()
    if sort_by == "rating":
        df = df.sort_values("rating", ascending=False)
    elif sort_by == "year":
        df = df.sort_values("year", ascending=False)
    elif sort_by == "title":
        df = df.sort_values("title")
    else:
        df = df.sort_values("popularity", ascending=False)
    total = len(df)
    start = (page - 1) * per_page
    end = start + per_page
    return jsonify({
        "movies": df_to_list(df.iloc[start:end]),
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": (total + per_page - 1) // per_page,
    })


@app.route("/api/movies/popular", methods=["GET"])
def get_popular():
    n = int(request.args.get("n", 12))
    return jsonify(df_to_list(rec.get_popular_movies(n)))


@app.route("/api/movies/toprated", methods=["GET"])
def get_top_rated():
    n = int(request.args.get("n", 12))
    return jsonify(df_to_list(rec.get_top_rated(n)))


@app.route("/api/movies/<int:movie_id>", methods=["GET"])
def get_movie(movie_id):
    movie = rec.get_movie_by_id(movie_id)
    if movie is None:
        return jsonify({"error": "Movie not found"}), 404
    return jsonify(movie_to_dict(movie))


@app.route("/api/search", methods=["GET"])
def search():
    query = request.args.get("q", "").strip()
    if not query:
        return jsonify([])
    n = int(request.args.get("n", 10))
    # Title match first
    df = rec.get_all_movies()
    title_mask = df["title"].str.contains(query, case=False, na=False)
    title_matches = df[title_mask]
    # Semantic search
    semantic = rec.search(query, n=n)
    # Combine (title matches first, then semantic)
    combined_ids = list(title_matches["movie_id"]) + [
        m for m in semantic["movie_id"] if m not in list(title_matches["movie_id"])
    ]
    combined_ids = combined_ids[:n]
    results = df[df["movie_id"].isin(combined_ids)]
    return jsonify(df_to_list(results))


@app.route("/api/recommend/<int:movie_id>", methods=["GET"])
def recommend_similar(movie_id):
    n = int(request.args.get("n", 10))
    user_id = request.args.get("user_id")
    if user_id:
        recs = rec.hybrid_recommend(movie_id, user_id=int(user_id), n=n)
    else:
        recs = rec.recommend_similar(movie_id, n=n)
    if len(recs) == 0:
        return jsonify([])
    return jsonify(df_to_list(recs))


@app.route("/api/recommend/user/<int:user_id>", methods=["GET"])
def recommend_for_user(user_id):
    n = int(request.args.get("n", 10))
    recs = rec.recommend_for_user(user_id, n=n)
    if len(recs) == 0:
        return jsonify({"message": "No recommendations yet. Rate some movies first!", "movies": []})
    return jsonify(df_to_list(recs))


@app.route("/api/rate", methods=["POST"])
def rate_movie():
    data = request.get_json()
    user_id = data.get("user_id")
    movie_id = data.get("movie_id")
    rating = data.get("rating")
    if not all([user_id, movie_id, rating]):
        return jsonify({"error": "user_id, movie_id, and rating are required"}), 400
    if not (1 <= float(rating) <= 10):
        return jsonify({"error": "Rating must be between 1 and 10"}), 400
    rec.add_user_rating(int(user_id), int(movie_id), float(rating))
    return jsonify({"success": True, "message": f"Rating {rating} saved for movie {movie_id}"})


@app.route("/api/genres", methods=["GET"])
def get_genres():
    df = rec.get_all_movies()
    genres = set()
    for g in df["genres"]:
        genres.update(g.split("|"))
    return jsonify(sorted(list(genres)))


@app.route("/api/movies/genre/<genre>", methods=["GET"])
def movies_by_genre(genre):
    n = int(request.args.get("n", 12))
    return jsonify(df_to_list(rec.get_movies_by_genre(genre, n)))


@app.route("/api/stats", methods=["GET"])
def get_stats():
    df = rec.get_all_movies()
    ratings_df = rec.ratings_df
    return jsonify({
        "total_movies": len(df),
        "total_ratings": len(ratings_df),
        "total_users": ratings_df["user_id"].nunique(),
        "avg_rating": round(float(df["rating"].mean()), 2),
        "genres": df["genres"].str.split("|").explode().value_counts().to_dict(),
    })


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
