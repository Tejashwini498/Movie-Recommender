"""
Movie Recommendation Engine
- Content-Based Filtering: TF-IDF on genres, cast, director, overview
- Collaborative Filtering: User-based CF with cosine similarity
- Hybrid: Weighted combination of both approaches
"""

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import MinMaxScaler
import pickle
import os

DATA_DIR = os.path.join(os.path.dirname(__file__), "../data")
MODEL_DIR = os.path.join(os.path.dirname(__file__), "../models")


class ContentBasedRecommender:
    def __init__(self):
        self.tfidf = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self.similarity_matrix = None
        self.movies_df = None

    def _build_soup(self, row):
        genres = row["genres"].replace("|", " ").lower()
        director = row["director"].replace(" ", "").lower()
        cast = row["cast"].replace("|", " ").replace(" ", "").lower()
        overview = row["overview"].lower() if pd.notna(row["overview"]) else ""
        # Weight genres and director more by repeating
        return f"{genres} {genres} {director} {director} {cast} {overview}"

    def fit(self, movies_df):
        self.movies_df = movies_df.reset_index(drop=True)
        self.movies_df["soup"] = self.movies_df.apply(self._build_soup, axis=1)
        tfidf_matrix = self.tfidf.fit_transform(self.movies_df["soup"])
        self.similarity_matrix = cosine_similarity(tfidf_matrix, tfidf_matrix)
        return self

    def recommend(self, movie_id, n=10):
        idx = self.movies_df.index[self.movies_df["movie_id"] == movie_id]
        if len(idx) == 0:
            return []
        idx = idx[0]
        sim_scores = list(enumerate(self.similarity_matrix[idx]))
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
        sim_scores = [s for s in sim_scores if s[0] != idx][:n]
        movie_indices = [s[0] for s in sim_scores]
        scores = [s[1] for s in sim_scores]
        results = self.movies_df.iloc[movie_indices].copy()
        results["similarity_score"] = scores
        return results

    def search(self, query, n=10):
        query_vec = self.tfidf.transform([query.lower()])
        tfidf_matrix = self.tfidf.transform(self.movies_df["soup"])
        scores = cosine_similarity(query_vec, tfidf_matrix)[0]
        top_idx = scores.argsort()[::-1][:n]
        results = self.movies_df.iloc[top_idx].copy()
        results["search_score"] = scores[top_idx]
        return results[results["search_score"] > 0.01]


class CollaborativeFilteringRecommender:
    def __init__(self):
        self.user_movie_matrix = None
        self.user_similarity = None
        self.movies_df = None

    def fit(self, movies_df, ratings_df):
        self.movies_df = movies_df
        self.user_movie_matrix = ratings_df.pivot_table(
            index="user_id", columns="movie_id", values="rating"
        ).fillna(0)
        # Normalize rows (mean-center each user)
        matrix = self.user_movie_matrix.values
        row_means = np.where(matrix > 0, matrix, np.nan)
        row_means = np.nanmean(row_means, axis=1, keepdims=True)
        normalized = np.where(matrix > 0, matrix - row_means, 0)
        self.user_similarity = cosine_similarity(normalized)
        return self

    def recommend_for_user(self, user_id, n=10):
        if user_id not in self.user_movie_matrix.index:
            return []
        user_idx = list(self.user_movie_matrix.index).index(user_id)
        sim_scores = self.user_similarity[user_idx]
        # Get top similar users (exclude self)
        similar_users = np.argsort(sim_scores)[::-1][1:21]
        # Movies this user hasn't rated
        user_ratings = self.user_movie_matrix.iloc[user_idx]
        unrated = user_ratings[user_ratings == 0].index
        # Predict ratings for unrated movies
        predictions = {}
        for movie_id in unrated:
            if movie_id not in self.user_movie_matrix.columns:
                continue
            movie_ratings = self.user_movie_matrix[movie_id].iloc[similar_users]
            weights = sim_scores[similar_users]
            rated_mask = movie_ratings > 0
            if rated_mask.sum() == 0:
                continue
            pred = np.dot(weights[rated_mask], movie_ratings[rated_mask]) / (
                np.sum(np.abs(weights[rated_mask])) + 1e-9
            )
            predictions[movie_id] = pred

        top_movies = sorted(predictions.items(), key=lambda x: x[1], reverse=True)[:n]
        movie_ids = [m[0] for m in top_movies]
        scores = [m[1] for m in top_movies]
        results = self.movies_df[self.movies_df["movie_id"].isin(movie_ids)].copy()
        score_map = dict(zip(movie_ids, scores))
        results["cf_score"] = results["movie_id"].map(score_map)
        return results.sort_values("cf_score", ascending=False)


class HybridRecommender:
    def __init__(self):
        self.cb = ContentBasedRecommender()
        self.cf = CollaborativeFilteringRecommender()
        self.movies_df = None
        self.ratings_df = None

    def fit(self, movies_df, ratings_df):
        self.movies_df = movies_df
        self.ratings_df = ratings_df
        self.cb.fit(movies_df)
        self.cf.fit(movies_df, ratings_df)
        print("✓ Content-Based model trained")
        print("✓ Collaborative Filtering model trained")
        return self

    def recommend_similar(self, movie_id, n=10):
        return self.cb.recommend(movie_id, n)

    def recommend_for_user(self, user_id, n=10):
        return self.cf.recommend_for_user(user_id, n)

    def hybrid_recommend(self, movie_id, user_id=None, n=10, cb_weight=0.6, cf_weight=0.4):
        cb_recs = self.cb.recommend(movie_id, n=20)
        if user_id and user_id in self.cf.user_movie_matrix.index:
            cf_recs = self.cf.recommend_for_user(user_id, n=20)
            # Merge scores
            scaler = MinMaxScaler()
            cb_map = {}
            if len(cb_recs) > 0:
                cb_recs["norm_cb"] = scaler.fit_transform(cb_recs[["similarity_score"]])
                cb_map = dict(zip(cb_recs["movie_id"], cb_recs["norm_cb"]))
            cf_map = {}
            if len(cf_recs) > 0 and "cf_score" in cf_recs.columns:
                cf_recs["norm_cf"] = scaler.fit_transform(cf_recs[["cf_score"]])
                cf_map = dict(zip(cf_recs["movie_id"], cf_recs["norm_cf"]))
            all_ids = set(list(cb_map.keys()) + list(cf_map.keys()))
            hybrid_scores = {}
            for mid in all_ids:
                score = cb_weight * cb_map.get(mid, 0) + cf_weight * cf_map.get(mid, 0)
                hybrid_scores[mid] = score
            top_ids = sorted(hybrid_scores, key=hybrid_scores.get, reverse=True)[:n]
            results = self.movies_df[self.movies_df["movie_id"].isin(top_ids)].copy()
            results["hybrid_score"] = results["movie_id"].map(hybrid_scores)
            return results.sort_values("hybrid_score", ascending=False)
        return cb_recs.head(n)

    def search(self, query, n=10):
        return self.cb.search(query, n)

    def get_movie_by_id(self, movie_id):
        row = self.movies_df[self.movies_df["movie_id"] == movie_id]
        return row.iloc[0] if len(row) > 0 else None

    def get_all_movies(self):
        return self.movies_df

    def get_popular_movies(self, n=12):
        return self.movies_df.nlargest(n, "vote_count")

    def get_top_rated(self, n=12):
        return self.movies_df.nlargest(n, "rating")

    def get_movies_by_genre(self, genre, n=12):
        mask = self.movies_df["genres"].str.contains(genre, case=False, na=False)
        return self.movies_df[mask].nlargest(n, "rating")

    def add_user_rating(self, user_id, movie_id, rating):
        new_row = pd.DataFrame([{"user_id": user_id, "movie_id": movie_id, "rating": rating}])
        self.ratings_df = pd.concat([self.ratings_df, new_row], ignore_index=True)
        # Refit CF model
        self.cf.fit(self.movies_df, self.ratings_df)
        return True


def train_and_save():
    movies_df = pd.read_csv(f"{DATA_DIR}/movies.csv")
    ratings_df = pd.read_csv(f"{DATA_DIR}/ratings.csv")
    rec = HybridRecommender()
    rec.fit(movies_df, ratings_df)
    os.makedirs(MODEL_DIR, exist_ok=True)
    with open(f"{MODEL_DIR}/recommender.pkl", "wb") as f:
        pickle.dump(rec, f)
    print(f"✓ Model saved to {MODEL_DIR}/recommender.pkl")
    return rec


def load_model():
    model_path = f"{MODEL_DIR}/recommender.pkl"
    if os.path.exists(model_path):
        with open(model_path, "rb") as f:
            return pickle.load(f)
    return train_and_save()


if __name__ == "__main__":
    rec = train_and_save()
    # Quick test
    movie = rec.get_movie_by_id(1)
    print(f"\nMovie: {movie['title']}")
    recs = rec.recommend_similar(1, n=5)
    print("Similar movies:")
    for _, r in recs.iterrows():
        print(f"  - {r['title']} ({r['year']}) | sim={r['similarity_score']:.3f}")
